# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** 大哥
- **What to call them:** 大哥
- **Pronouns:** *(optional)*
- **Timezone:** GMT+8
- **Notes:** 首次交流于2026年2月5日，是爪子哥的创建者和主要用户

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
