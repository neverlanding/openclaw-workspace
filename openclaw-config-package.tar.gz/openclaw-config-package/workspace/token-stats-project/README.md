# Token消耗统计项目

## 📁 项目结构

```
token-stats-project/
├── 2026/                    # 年份文件夹
│   ├── 01/                 # 月份文件夹
│   │   ├── 2026-01-01.md   # 每日统计报告
│   │   ├── 2026-01-02.md
│   │   └── ...
│   ├── 02/
│   └── ...
├── scripts/
│   └── generate-daily-report.sh  # 日报生成脚本
└── README.md               # 项目说明
```

## ⚙️ 自动执行

**定时任务：** 每天20:00自动执行

**Cron配置：**
```
0 20 * * * /home/gary/.openclaw/workspace/token-stats-project/scripts/generate-daily-report.sh
```

## 📊 统计内容

每日自动从 `MEMORY.md` 提取：
- 子Agent任务列表
- Token消耗数量（input + output）
- 使用模型类型
- 任务耗时
- 完成状态

## 📄 报告格式

每个日报文件包含：
- 日期和生成时间
- 任务统计表格
- 当日总计
- 数据来源标注

## 🔧 手动执行

如需手动生成报告：
```bash
bash /home/gary/.openclaw/workspace/token-stats-project/scripts/generate-daily-report.sh
```

## 📝 查看历史

按年月查看历史记录：
```bash
ls -la /home/gary/.openclaw/workspace/token-stats-project/2026/02/
```
