#!/bin/bash
# OpenClaw 配置恢复脚本
# 用于在现有 OpenClaw 安装中恢复配置

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"

# 检查 OpenClaw 是否已安装
check_openclaw() {
    if ! command -v openclaw &> /dev/null; then
        print_error "OpenClaw 未安装，请先运行 install.sh"
        exit 1
    fi
    print_success "OpenClaw 已安装: $(openclaw --version)"
}

# 备份现有配置
backup_existing() {
    print_info "备份现有配置..."
    
    BACKUP_DIR="${HOME}/.openclaw/backup-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    
    if [ -f "${HOME}/.openclaw/openclaw.json" ]; then
        cp "${HOME}/.openclaw/openclaw.json" "$BACKUP_DIR/"
        print_success "备份 openclaw.json 到 $BACKUP_DIR"
    fi
    
    if [ -d "${HOME}/.openclaw/workspace" ]; then
        cp -r "${HOME}/.openclaw/workspace" "$BACKUP_DIR/"
        print_success "备份 workspace 到 $BACKUP_DIR"
    fi
    
    if [ -f "${HOME}/.openclaw/cron/jobs.json" ]; then
        mkdir -p "$BACKUP_DIR/cron"
        cp "${HOME}/.openclaw/cron/jobs.json" "$BACKUP_DIR/cron/"
        print_success "备份 cron jobs 到 $BACKUP_DIR"
    fi
}

# 恢复配置
restore_configs() {
    print_info "恢复配置..."
    
    # 恢复主配置
    if [ -f "$PACKAGE_DIR/config/openclaw.json" ]; then
        cp "$PACKAGE_DIR/config/openclaw.json" "${HOME}/.openclaw/"
        print_success "恢复 openclaw.json"
    fi
    
    # 恢复 cron 配置
    if [ -f "$PACKAGE_DIR/config/jobs.json" ]; then
        mkdir -p "${HOME}/.openclaw/cron"
        cp "$PACKAGE_DIR/config/jobs.json" "${HOME}/.openclaw/cron/"
        print_success "恢复 cron jobs"
    fi
    
    # 恢复工作区
    if [ -d "$PACKAGE_DIR/workspace" ]; then
        mkdir -p "${HOME}/.openclaw/workspace"
        cp -r "$PACKAGE_DIR/workspace/"* "${HOME}/.openclaw/workspace/" 2>/dev/null || true
        print_success "恢复 workspace"
    fi
}

# 验证恢复
verify_restore() {
    print_info "验证恢复..."
    
    if [ -f "${HOME}/.openclaw/openclaw.json" ]; then
        print_success "openclaw.json 已恢复"
    else
        print_error "openclaw.json 恢复失败"
    fi
    
    if [ -d "${HOME}/.openclaw/workspace" ]; then
        print_success "workspace 已恢复"
        echo "工作区内容:"
        ls -la "${HOME}/.openclaw/workspace"
    fi
}

# 显示帮助
show_help() {
    echo ""
    echo "========================================"
    print_success "配置恢复完成!"
    echo "========================================"
    echo ""
    echo "备份位置: ${HOME}/.openclaw/backup-$(date +%Y%m%d-%H%M%S)"
    echo ""
    echo "如需重新启动 OpenClaw:"
    echo "  openclaw gateway restart"
    echo ""
}

# 主函数
main() {
    echo "========================================"
    echo "  OpenClaw 配置恢复脚本"
    echo "========================================"
    echo ""
    
    check_openclaw
    echo ""
    backup_existing
    echo ""
    restore_configs
    echo ""
    verify_restore
    echo ""
    show_help
}

# 运行主函数
main
