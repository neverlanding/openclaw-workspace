#!/bin/bash
# OpenClaw 一键安装脚本
# 用于在新环境中快速部署OpenClaw配置

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    print_info "检查依赖项..."
    
    # 检查 Git
    if ! command -v git &> /dev/null; then
        print_error "未找到 Git，请先安装 Git"
        echo "  Ubuntu/Debian: sudo apt-get install git"
        echo "  CentOS/RHEL: sudo yum install git"
        echo "  macOS: brew install git"
        exit 1
    fi
    print_success "Git 已安装"
    
    # 检查 Node.js
    if ! command -v node &> /dev/null; then
        print_error "未找到 Node.js，请先安装 Node.js (建议 v18+)"
        echo "  推荐使用 nvm 安装:"
        echo "    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash"
        echo "    nvm install 22"
        exit 1
    fi
    
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        print_warning "Node.js 版本较低 ($NODE_VERSION)，建议升级到 v18+"
    else
        print_success "Node.js 已安装: $(node --version)"
    fi
    
    # 检查 npm
    if ! command -v npm &> /dev/null; then
        print_error "未找到 npm，请先安装 npm"
        exit 1
    fi
    print_success "npm 已安装: $(npm --version)"
}

# 安装 OpenClaw
install_openclaw() {
    print_info "安装 OpenClaw..."
    
    # 检查是否已安装
    if command -v openclaw &> /dev/null; then
        print_warning "OpenClaw 已安装，跳过安装步骤"
        openclaw --version
        return
    fi
    
    # 使用 npm 安装
    npm install -g openclaw
    
    if command -v openclaw &> /dev/null; then
        print_success "OpenClaw 安装成功"
        openclaw --version
    else
        print_error "OpenClaw 安装失败"
        exit 1
    fi
}

# 创建配置目录
setup_directories() {
    print_info "设置配置目录..."
    
    export OPENCLAW_DIR="${HOME}/.openclaw"
    export WORKSPACE_DIR="${OPENCLAW_DIR}/workspace"
    
    mkdir -p "$OPENCLAW_DIR"
    mkdir -p "$WORKSPACE_DIR"
    
    print_success "目录创建完成: $OPENCLAW_DIR"
}

# 恢复配置文件
restore_configs() {
    print_info "恢复配置文件..."
    
    # 获取脚本所在目录
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
    
    # 复制主配置文件
    if [ -f "$PACKAGE_DIR/config/openclaw.json" ]; then
        cp "$PACKAGE_DIR/config/openclaw.json" "$OPENCLAW_DIR/"
        print_success "恢复 openclaw.json"
    else
        print_warning "未找到 openclaw.json，将使用默认配置"
    fi
    
    # 复制 cron 配置
    if [ -f "$PACKAGE_DIR/config/jobs.json" ]; then
        mkdir -p "$OPENCLAW_DIR/cron"
        cp "$PACKAGE_DIR/config/jobs.json" "$OPENCLAW_DIR/cron/"
        print_success "恢复 cron jobs 配置"
    fi
    
    # 恢复工作区
    if [ -d "$PACKAGE_DIR/workspace" ]; then
        cp -r "$PACKAGE_DIR/workspace/"* "$WORKSPACE_DIR/" 2>/dev/null || true
        print_success "恢复工作区文件"
    fi
}

# 配置 API Keys
configure_api_keys() {
    print_info "配置 API Keys..."
    print_warning "请根据你的需求配置以下 API Keys:"
    echo ""
    echo "1. Feishu (飞书) 配置:"
    echo "   - 编辑 ~/.openclaw/openclaw.json"
    echo "   - 在 channels.feishu 中配置 appId 和 appSecret"
    echo ""
    echo "2. AI 模型 API Keys:"
    echo "   - Qwen Portal: 配置 OAuth 认证"
    echo "   - Moonshot: 配置 API Key"
    echo "   - ZAI: 配置 API Key"
    echo "   - Kimi Coding: 配置 API Key"
    echo ""
    echo "3. Web 搜索 API (可选):"
    echo "   - Brave Search API Key"
    echo ""
    echo "配置文件位置: ~/.openclaw/openclaw.json"
    echo ""
    
    read -p "是否现在编辑配置文件? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if command -v nano &> /dev/null; then
            nano ~/.openclaw/openclaw.json
        elif command -v vim &> /dev/null; then
            vim ~/.openclaw/openclaw.json
        else
            print_warning "未找到编辑器，请手动编辑 ~/.openclaw/openclaw.json"
        fi
    fi
}

# 安装插件
install_plugins() {
    print_info "安装插件..."
    
    # 安装 Feishu 插件
    if ! [ -d "$OPENCLAW_DIR/extensions/feishu" ]; then
        print_info "安装 Feishu 插件..."
        openclaw plugins install @m1heng-clawd/feishu || print_warning "Feishu 插件安装失败，请手动安装"
    else
        print_success "Feishu 插件已存在"
    fi
}

# 验证安装
verify_installation() {
    print_info "验证安装..."
    
    # 检查 openclaw 命令
    if ! command -v openclaw &> /dev/null; then
        print_error "OpenClaw 命令不可用"
        return 1
    fi
    
    # 检查配置文件
    if [ -f "$OPENCLAW_DIR/openclaw.json" ]; then
        print_success "配置文件存在"
    else
        print_warning "配置文件不存在"
    fi
    
    # 检查工作区
    if [ -d "$WORKSPACE_DIR" ]; then
        print_success "工作区目录存在"
        ls -la "$WORKSPACE_DIR"
    fi
    
    print_success "安装验证完成"
}

# 显示使用说明
show_usage() {
    echo ""
    echo "========================================"
    print_success "OpenClaw 安装完成!"
    echo "========================================"
    echo ""
    echo "常用命令:"
    echo "  openclaw --version     # 查看版本"
    echo "  openclaw doctor        # 检查健康状态"
    echo "  openclaw gateway start # 启动网关"
    echo "  openclaw help          # 查看帮助"
    echo ""
    echo "配置文件: ~/.openclaw/openclaw.json"
    echo "工作目录: ~/.openclaw/workspace"
    echo ""
    echo "启动 OpenClaw:"
    echo "  1. 确保已配置所有 API Keys"
    echo "  2. 运行: openclaw gateway start"
    echo "  3. 在另一个终端运行: openclaw connect feishu"
    echo ""
    echo "更多信息请参考 README.md"
    echo ""
}

# 主函数
main() {
    echo "========================================"
    echo "  OpenClaw 一键安装脚本"
    echo "========================================"
    echo ""
    
    check_dependencies
    echo ""
    install_openclaw
    echo ""
    setup_directories
    echo ""
    restore_configs
    echo ""
    install_plugins
    echo ""
    verify_installation
    echo ""
    configure_api_keys
    echo ""
    show_usage
}

# 运行主函数
main
