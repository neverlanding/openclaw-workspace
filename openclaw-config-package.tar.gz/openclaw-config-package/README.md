# OpenClaw 配置部署包

这是一个完整的 OpenClaw 配置包，可用于在新环境中快速部署或恢复现有配置。

## 📦 包内容

```
openclaw-config-package/
├── config/              # 配置文件
│   ├── openclaw.json    # 主配置文件（包含模型、通道、网关等配置）
│   └── jobs.json        # Cron 任务配置
├── workspace/           # 工作区文件
│   ├── AGENTS.md        # Agent 配置指南
│   ├── MEMORY.md        # 长期记忆
│   ├── SOUL.md          # 核心人格配置
│   ├── USER.md          # 用户信息
│   ├── TOOLS.md         # 工具配置
│   ├── IDENTITY.md      # 身份配置
│   ├── HEARTBEAT.md     # 心跳任务配置
│   ├── memory/          # 记忆目录
│   └── ...              # 其他工作区文件
├── scripts/
│   ├── install.sh       # 一键安装脚本（新环境）
│   └── restore.sh       # 配置恢复脚本（现有环境）
└── README.md            # 本文件
```

## 🚀 快速开始

### 全新安装（新环境）

1. **解压部署包**
   ```bash
   tar -xzf openclaw-config-package.tar.gz
   cd openclaw-config-package
   ```

2. **运行安装脚本**
   ```bash
   chmod +x scripts/install.sh
   ./scripts/install.sh
   ```

3. **配置 API Keys**
   
   安装脚本会提示你配置 API Keys，或手动编辑：
   ```bash
   nano ~/.openclaw/openclaw.json
   ```

4. **启动 OpenClaw**
   ```bash
   # 启动网关
   openclaw gateway start
   
   # 在另一个终端连接 Feishu
   openclaw connect feishu
   ```

### 恢复配置（现有环境）

如果已安装 OpenClaw，只想恢复配置：

```bash
cd openclaw-config-package
chmod +x scripts/restore.sh
./scripts/restore.sh
```

## ⚙️ 配置说明

### 主配置文件 (openclaw.json)

包含以下主要配置：

- **Models**: AI 模型配置
  - Qwen Portal (coder-model, vision-model)
  - Kimi Coding (k2p5)
  - Moonshot (kimi-k2-0905-preview, kimi-k2.5)
  - ZAI (glm-4.7)

- **Channels**: 通道配置
  - Feishu (飞书) - 已配置 appId

- **Gateway**: 网关配置
  - 端口: 18789
  - 认证模式: token

- **Plugins**: 插件配置
  - Feishu 插件

### 需要配置的 API Keys

⚠️ **重要**: 以下敏感信息需要在部署后配置：

1. **Feishu (飞书)**
   - `appId`: 飞书应用 ID
   - `appSecret`: 飞书应用密钥

2. **AI 模型 API Keys**
   - Qwen Portal: OAuth 认证
   - Moonshot: API Key
   - ZAI: API Key
   - Kimi Coding: API Key

3. **Web 搜索 (可选)**
   - Brave Search API Key

编辑配置文件：
```bash
nano ~/.openclaw/openclaw.json
```

## 📋 系统要求

- **操作系统**: Linux, macOS, Windows (WSL)
- **Node.js**: v18+ (推荐 v22)
- **npm**: v8+
- **Git**: 任意版本

## 🔧 手动安装步骤

如果不想使用自动脚本，可以手动安装：

1. **安装 OpenClaw**
   ```bash
   npm install -g openclaw
   ```

2. **创建目录结构**
   ```bash
   mkdir -p ~/.openclaw/workspace
   mkdir -p ~/.openclaw/cron
   ```

3. **复制配置文件**
   ```bash
   cp config/openclaw.json ~/.openclaw/
   cp config/jobs.json ~/.openclaw/cron/
   cp -r workspace/* ~/.openclaw/workspace/
   ```

4. **安装插件**
   ```bash
   openclaw plugins install @m1heng-clawd/feishu
   ```

5. **配置 API Keys**
   ```bash
   nano ~/.openclaw/openclaw.json
   ```

## 📝 工作区内容

工作区包含以下重要文件：

- **AGENTS.md**: Agent 行为规范
- **MEMORY.md**: 长期记忆和上下文
- **SOUL.md**: AI 人格配置
- **USER.md**: 用户信息
- **TOOLS.md**: 本地工具配置
- **memory/**: 记忆文件目录
- **skills/**: 自定义技能

## 🔒 安全注意事项

1. **不要分享此配置包** - 包含敏感配置信息
2. **部署后修改 API Keys** - 使用自己的 API Keys
3. **定期备份** - 建议定期备份 `~/.openclaw/` 目录
4. **网关 Token** - 生产环境应重新生成网关认证 Token

## 🆘 故障排除

### 安装失败

```bash
# 检查 Node.js 版本
node --version  # 需要 v18+

# 检查 npm
npm --version

# 清除 npm 缓存
npm cache clean --force
```

### 配置问题

```bash
# 验证配置
openclaw doctor

# 查看日志
openclaw logs

# 重置配置（谨慎使用）
mv ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.bak
```

### 插件问题

```bash
# 重新安装插件
openclaw plugins install @m1heng-clawd/feishu

# 查看已安装插件
openclaw plugins list
```

## 📚 参考资源

- [OpenClaw 官方文档](https://github.com/m1heng/OpenClaw)
- [Feishu 开放平台](https://open.feishu.cn/)
- [Qwen AI](https://qwen.ai/)
- [Moonshot AI](https://moonshot.cn/)

## 📅 打包信息

- **打包日期**: 2026-02-26
- **OpenClaw 版本**: 2026.2.24
- **配置文件版本**: 2026.2.24

---

如有问题，请参考 OpenClaw 官方文档或提交 Issue。
